// Módulo simbólico de respuesta por voz
module.exports = async function emitirRespuestaVoz(texto) {
  console.log("🔊 Voz IA simulada:", texto);
  // Aquí se conectaría ElevenLabs o TTS real
};